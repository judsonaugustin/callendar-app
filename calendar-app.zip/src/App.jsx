import React from "react";
import CalendarApp from "./components/CalendarApp";

function App() {
  return (
    <>
      <CalendarApp />
    </>
  );
}

export default App;
